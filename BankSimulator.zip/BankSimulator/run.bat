@echo off
rem Run the console application (run build.bat first)
cd /d "%~dp0"
java -cp "out;lib\*" com.bank.sim.controller.Main
