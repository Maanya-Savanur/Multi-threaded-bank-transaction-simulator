package com.bank.sim.exception;

public class InsufficientFundsException extends BankException {

    public InsufficientFundsException(String m) { super(m); }
}
