package com.bank.sim.exception;

public class AccountNotFoundException extends BankException {

    public AccountNotFoundException(String m) { super(m); }
}
