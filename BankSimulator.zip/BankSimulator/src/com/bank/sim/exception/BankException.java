package com.bank.sim.exception;

/** Base of all project exceptions (checked, so the compiler forces callers to handle them). */
public class BankException extends Exception {

    public BankException(String message) { super(message); }

    public BankException(String message, Throwable cause) { super(message, cause); }
}
