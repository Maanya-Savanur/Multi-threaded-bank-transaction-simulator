package com.bank.sim.exception;

public class InvalidAmountException extends BankException {

    public InvalidAmountException(String m) { super(m); }
}
