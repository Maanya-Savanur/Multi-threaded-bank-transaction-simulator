package com.bank.sim.worker;

import com.bank.sim.model.Transaction;
import com.bank.sim.service.Statistics;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

/** Low-priority daemon thread that prints progress while a simulation runs. */
public class MonitorThread extends Thread {

    private final ExecutorService pool;
    private final BlockingQueue<Transaction> queue;
    private final Statistics stats;
    private final boolean verbose;

    public MonitorThread(ExecutorService pool) {
        this(pool, null, null, false);
    }

    public MonitorThread(ExecutorService pool, BlockingQueue<Transaction> queue,
                         Statistics stats, boolean verbose) {
        super("Monitor");
        this.pool = pool;
        this.queue = queue;
        this.stats = stats;
        this.verbose = verbose;
    }

    @Override
    public void run() {
        try {
            while (!isInterrupted()) {
                Thread.sleep(500);
                if (verbose && stats != null) {
                    int active = (pool instanceof ThreadPoolExecutor tpe) ? tpe.getActiveCount() : -1;
                    System.out.println("[Monitor] processed=" + stats.getProcessed()
                            + " queued=" + (queue == null ? "?" : queue.size())
                            + " activeWorkers=" + active);
                }
            }
        } catch (InterruptedException e) {
            // normal stop
        }
    }
}
