package com.bank.sim.worker;

import com.bank.sim.exception.AccountNotFoundException;
import com.bank.sim.exception.BankException;
import com.bank.sim.exception.InsufficientFundsException;
import com.bank.sim.exception.InvalidAmountException;
import com.bank.sim.model.Transaction;
import com.bank.sim.service.BankService;

import java.util.concurrent.BlockingQueue;

/** Consumer: worker threads take requests from the queue and execute them. */
public class TransactionProcessor implements Runnable {

    private final BlockingQueue<Transaction> queue;
    private final BankService bank;

    public TransactionProcessor(BlockingQueue<Transaction> q, BankService b) {
        this.queue = q;
        this.bank = b;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Transaction t = queue.take(); // waits when queue is empty
                if (t == Transaction.POISON) break;
                try {
                    switch (t.getType()) {
                        case DEPOSIT -> bank.deposit(t.getFrom(), t.getAmount());
                        case WITHDRAW -> bank.withdraw(t.getFrom(), t.getAmount());
                        case TRANSFER -> bank.transfer(t.getFrom(), t.getTo(), t.getAmount());
                    }
                } catch (InsufficientFundsException | AccountNotFoundException
                         | InvalidAmountException e) {
                    bank.recordFailure(t, e.getMessage());
                } catch (BankException e) {
                    String why = (e.getCause() != null)
                            ? "Storage error: " + e.getCause()
                            : e.getMessage();
                    bank.recordFailure(t, why);
                } catch (RuntimeException e) {
                    bank.recordFailure(t, "Unexpected error: " + e);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
