package com.bank.sim.worker;

import com.bank.sim.model.Transaction;
import com.bank.sim.model.TxnType;

import java.util.Random;
import java.util.concurrent.BlockingQueue;

/** Producer: creates random requests and places them in the shared queue. */
public class TransactionGenerator implements Runnable {

    private final BlockingQueue<Transaction> queue;
    private final int count, workers, accountCount;
    private final boolean transfersOnly;

    public TransactionGenerator(BlockingQueue<Transaction> queue, int count,
                                int workers, int accountCount) {
        this(queue, count, workers, accountCount, false);
    }

    public TransactionGenerator(BlockingQueue<Transaction> queue, int count,
                                int workers, int accountCount, boolean transfersOnly) {
        this.queue = queue;
        this.count = count;
        this.workers = workers;
        this.accountCount = accountCount;
        this.transfersOnly = transfersOnly;
    }

    @Override
    public void run() {
        Random r = new Random();
        try {
            for (int i = 0; i < count; i++) {
                TxnType type = transfersOnly ? TxnType.TRANSFER : TxnType.values()[r.nextInt(3)];
                int from = 1 + r.nextInt(accountCount);
                int to = 1 + r.nextInt(accountCount);
                long amt = 100 + r.nextInt(50_000); // 1 Rs to about 500 Rs, in paise
                queue.put(new Transaction(type, from, to, amt)); // blocks if full
            }
            for (int i = 0; i < workers; i++) {
                queue.put(Transaction.POISON); // stop signal, one per worker
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
