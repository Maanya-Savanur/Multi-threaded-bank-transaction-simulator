package com.bank.sim.dao;

import com.bank.sim.exception.BankException;
import com.bank.sim.model.Account;
import com.bank.sim.model.Transaction;

/** Storage contract. Switching SQLite to MySQL only changes the implementing class. */
public interface AccountRepository {

    void save(Account account) throws BankException;

    Account findById(int id) throws BankException;

    void logTxn(Transaction txn) throws BankException;

    default void close() { }
}
