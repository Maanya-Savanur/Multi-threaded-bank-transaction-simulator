package com.bank.sim.dao;

import com.bank.sim.exception.BankException;
import com.bank.sim.model.Account;
import com.bank.sim.model.CurrentAccount;
import com.bank.sim.model.SavingsAccount;
import com.bank.sim.model.Transaction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;

/** JDBC implementation (tested with SQLite). Needs the JDBC driver jar only at run time. */
public class JdbcAccountRepository implements AccountRepository {

    private final Connection conn;

    public JdbcAccountRepository(String url) throws BankException {
        Connection c;
        try {
            c = DriverManager.getConnection(url);
            try (Statement st = c.createStatement()) {
                st.execute("CREATE TABLE IF NOT EXISTS accounts ("
                        + "id INTEGER PRIMARY KEY, holder VARCHAR(100), "
                        + "type VARCHAR(20), balance BIGINT)");
                st.execute("CREATE TABLE IF NOT EXISTS txn_log ("
                        + "txn_id BIGINT, type VARCHAR(20), from_id INTEGER, to_id INTEGER, "
                        + "amount BIGINT, status VARCHAR(20), message VARCHAR(255), "
                        + "created VARCHAR(40))");
            }
        } catch (SQLException e) {
            throw new BankException("Cannot open database: " + e.getMessage(), e);
        }
        this.conn = c;
    }

    @Override
    public synchronized void save(Account a) throws BankException {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE accounts SET balance=? WHERE id=?")) {
            ps.setLong(1, a.getBalance());
            ps.setInt(2, a.getId());
            if (ps.executeUpdate() == 0) {
                try (PreparedStatement ins = conn.prepareStatement(
                        "INSERT INTO accounts (id, holder, type, balance) VALUES (?,?,?,?)")) {
                    ins.setInt(1, a.getId());
                    ins.setString(2, a.getHolder());
                    ins.setString(3, a.getType());
                    ins.setLong(4, a.getBalance());
                    ins.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new BankException("Could not save account " + a.getId(), e); // chained
        }
    }

    @Override
    public synchronized Account findById(int id) throws BankException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT holder, type, balance FROM accounts WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                String holder = rs.getString(1);
                String type = rs.getString(2);
                long balance = rs.getLong(3);
                return "SAVINGS".equals(type)
                        ? new SavingsAccount(id, holder, balance)
                        : new CurrentAccount(id, holder, balance);
            }
        } catch (SQLException e) {
            throw new BankException("Could not read account " + id, e);
        }
    }

    @Override
    public synchronized void logTxn(Transaction t) throws BankException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO txn_log (txn_id, type, from_id, to_id, amount, status, message, created) "
                        + "VALUES (?,?,?,?,?,?,?,?)")) {
            ps.setLong(1, t.getId());
            ps.setString(2, t.getType().name());
            ps.setInt(3, t.getFrom());
            ps.setInt(4, t.getTo());
            ps.setLong(5, t.getAmount());
            ps.setString(6, t.getStatus().name());
            ps.setString(7, t.getMessage());
            ps.setString(8, LocalDateTime.now().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new BankException("Could not log transaction " + t.getId(), e);
        }
    }

    @Override
    public synchronized void close() {
        try {
            conn.close();
        } catch (SQLException e) {
            // ignore on shutdown
        }
    }
}
