package com.bank.sim.dao;

import com.bank.sim.model.Account;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Generic in-memory store. Bounded type parameter: only Account or its subclasses. */
public class Repository<T extends Account> {

    private final Map<Integer, T> items = new ConcurrentHashMap<>();

    public void add(T item) { items.put(item.getId(), item); }

    public T find(int id) { return items.get(id); }

    public Collection<T> all() { return items.values(); }
}
