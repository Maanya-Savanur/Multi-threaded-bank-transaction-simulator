package com.bank.sim.util;

import com.bank.sim.model.TxnType;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/** Reads config.properties; every key has a default so the file is optional. */
public class ConfigReader {

    private final Properties props = new Properties();

    public ConfigReader(String path) {
        try (FileInputStream in = new FileInputStream(path)) {
            props.load(in);
        } catch (IOException e) {
            // file missing: defaults are used
        }
    }

    public String get(String key, String def) {
        return props.getProperty(key, def).trim();
    }

    public int getInt(String key, int def) {
        try {
            return Integer.parseInt(get(key, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public long getLong(String key, long def) {
        try {
            return Long.parseLong(get(key, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Uses Enum.valueOf() to turn config text into a TxnType. */
    public TxnType getTxnType(String key, TxnType def) {
        try {
            return TxnType.valueOf(get(key, def.name()).toUpperCase());
        } catch (IllegalArgumentException e) {
            return def;
        }
    }
}
