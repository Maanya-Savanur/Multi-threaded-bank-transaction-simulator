package com.bank.sim.util;

/** Generic class with two type parameters, e.g. Pair&lt;Integer, Long&gt; = account id and balance. */
public class Pair<K, V> {

    private final K key;
    private final V value;

    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() { return key; }

    public V getValue() { return value; }
}
