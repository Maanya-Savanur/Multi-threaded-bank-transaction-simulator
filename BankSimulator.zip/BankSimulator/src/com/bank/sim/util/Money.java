package com.bank.sim.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/** Conversion between rupees (text) and paise (long). */
public final class Money {

    private Money() { }

    /** 1000000 paise -> "Rs 10,000.00" */
    public static String format(long paise) {
        boolean negative = paise < 0;
        long p = Math.abs(paise);
        return (negative ? "-" : "") + "Rs "
                + String.format(Locale.US, "%,d.%02d", p / 100, p % 100);
    }

    /** "250.50" -> 25050. Throws NumberFormatException / ArithmeticException on bad input. */
    public static long parse(String rupees) {
        return new BigDecimal(rupees.trim())
                .movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact();
    }
}
