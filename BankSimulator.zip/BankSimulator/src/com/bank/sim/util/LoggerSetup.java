package com.bank.sim.util;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/** Sends all "com.bank.sim" log output to bank.log (not to the console). */
public final class LoggerSetup {

    private LoggerSetup() { }

    public static void init() {
        System.setProperty("java.util.logging.SimpleFormatter.format",
                "%1$tF %1$tT [%4$s] %5$s%n");
        Logger root = Logger.getLogger("com.bank.sim");
        root.setUseParentHandlers(false); // keep the console clean
        for (Handler h : root.getHandlers()) {
            root.removeHandler(h);
        }
        try {
            FileHandler fh = new FileHandler("bank.log", true);
            fh.setFormatter(new SimpleFormatter());
            root.addHandler(fh);
            root.setLevel(Level.INFO);
        } catch (IOException e) {
            System.err.println("Could not open bank.log: " + e.getMessage());
        }
    }
}
