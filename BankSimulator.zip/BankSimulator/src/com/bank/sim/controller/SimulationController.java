package com.bank.sim.controller;

import com.bank.sim.model.Transaction;
import com.bank.sim.service.BankService;
import com.bank.sim.worker.MonitorThread;
import com.bank.sim.worker.TransactionGenerator;
import com.bank.sim.worker.TransactionProcessor;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Starts the producer, the worker pool and the monitor, then waits for completion. */
public class SimulationController {

    /** Outcome of one simulation run. */
    public static class Result {
        public final int total, workers, success, failed;
        public final double seconds, throughput;
        public final long before, after, expectedAfter;

        public Result(int total, int workers, int success, int failed, double seconds,
                      double throughput, long before, long after, long expectedAfter) {
            this.total = total;
            this.workers = workers;
            this.success = success;
            this.failed = failed;
            this.seconds = seconds;
            this.throughput = throughput;
            this.before = before;
            this.after = after;
            this.expectedAfter = expectedAfter;
        }

        public boolean invariantOk() { return after == expectedAfter; }
    }

    /**
     * @param transfersOnly true = only transfers, so the total money must stay exactly the same
     * @param verbose       true = print monitor lines and producer state
     */
    public Result run(BankService bank, int total, int workers, boolean transfersOnly,
                      boolean verbose) throws InterruptedException {
        int n = bank.getAccounts().size();
        bank.getStats().reset();
        long before = bank.totalBalance();
        long netBefore = bank.getNetExternal();

        BlockingQueue<Transaction> queue = new LinkedBlockingQueue<>(500);
        ExecutorService pool = Executors.newFixedThreadPool(workers);
        Thread producer = new Thread(
                new TransactionGenerator(queue, total, workers, n, transfersOnly), "Generator");
        MonitorThread monitor = new MonitorThread(pool, queue, bank.getStats(), verbose);
        monitor.setPriority(Thread.MIN_PRIORITY); // lowered priority
        monitor.setDaemon(true);

        long start = System.nanoTime();
        producer.start();
        monitor.start();
        for (int i = 0; i < workers; i++) {
            pool.submit(new TransactionProcessor(queue, bank));
        }

        producer.join(); // wait for the producer
        if (verbose) {
            System.out.println("Producer alive? " + producer.isAlive()
                    + " state=" + producer.getState());
        }
        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.MINUTES);
        double seconds = (System.nanoTime() - start) / 1_000_000_000.0;
        monitor.interrupt();

        double throughput = (double) total / Math.max(seconds, 1e-9); // type cast
        long after = bank.totalBalance();
        long expected = before + (bank.getNetExternal() - netBefore);
        return new Result(total, workers, bank.getStats().getSuccess(), bank.getStats().getFailed(),
                seconds, throughput, before, after, expected);
    }
}
