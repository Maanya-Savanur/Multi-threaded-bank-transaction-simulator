package com.bank.sim.controller;

import com.bank.sim.exception.AccountNotFoundException;
import com.bank.sim.exception.BankException;
import com.bank.sim.exception.InsufficientFundsException;
import com.bank.sim.exception.InvalidAmountException;
import com.bank.sim.model.Account;
import com.bank.sim.model.TxnType;
import com.bank.sim.service.BankService;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Dependency-free test runner (no JUnit needed). Covers the verification checklist:
 * unit checks, concurrency stress, deadlock test.
 * Run: java -cp out com.bank.sim.controller.SelfTest
 */
public class SelfTest {

    private interface Op { void run() throws Exception; }

    private static int passed = 0, failed = 0;

    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
    }

    private static boolean throwsType(Class<? extends Exception> type, Op op) {
        try {
            op.run();
            return false;
        } catch (Exception e) {
            return type.isInstance(e);
        }
    }

    public static void main(String[] args) throws Exception {
        basics();
        exceptions();
        misc();
        stress();
        deadlock();
        System.out.println();
        System.out.println("Passed: " + passed + "  Failed: " + failed);
        System.exit(failed == 0 ? 0 : 1);
    }

    private static void basics() throws Exception {
        BankService b = new BankService();
        b.createAccounts(2, 1_000_000); // 1 = Savings, 2 = Current
        b.deposit(1, 500);
        check("deposit adds amount", b.getAccount(1).getBalance() == 1_000_500);
        b.withdraw(2, 200);
        check("withdraw subtracts amount", b.getAccount(2).getBalance() == 999_800);
        b.transfer(1, 2, 1000); // 3-arg default method
        check("transfer debits source", b.getAccount(1).getBalance() == 999_500);
        check("transfer credits target", b.getAccount(2).getBalance() == 1_000_800);
        check("transfer keeps total", b.totalBalance() == 2_000_300 && b.getNetExternal() == 300);
    }

    private static void exceptions() throws Exception {
        BankService b = new BankService();
        b.createAccounts(2, 1_000_000);
        check("negative amount rejected", throwsType(InvalidAmountException.class, () -> b.deposit(1, -5)));
        check("zero amount rejected", throwsType(InvalidAmountException.class, () -> b.withdraw(1, 0)));
        check("same account transfer rejected", throwsType(InvalidAmountException.class, () -> b.transfer(1, 1, 100)));
        check("unknown account rejected", throwsType(AccountNotFoundException.class, () -> b.deposit(99, 100)));
        check("unknown transfer target rejected", throwsType(AccountNotFoundException.class, () -> b.transfer(1, 99, 100)));
        check("savings minimum balance enforced",
                throwsType(InsufficientFundsException.class, () -> b.withdraw(1, 950_000)));
        check("current account may reach zero", noThrow(() -> b.withdraw(2, 1_000_000)));
        check("failed operation changes nothing", b.getAccount(1).getBalance() == 1_000_000);
    }

    private static boolean noThrow(Op op) {
        try {
            op.run();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void misc() throws Exception {
        BankService b = new BankService();
        b.createAccounts(2, 1_000_000);
        Account a = b.getAccount(1);
        check("dynamic dispatch: savings minimum", a.minimumBalance() == 100_000);
        check("dynamic dispatch: current minimum", b.getAccount(2).minimumBalance() == 0);
        check("inner class snapshot", a.new Snapshot().toString().contains("balance=1000000"));
        check("enum valueOf", TxnType.valueOf("TRANSFER") == TxnType.TRANSFER);
        check("MAX_THREADS constant", Account.MAX_THREADS == 20);
    }

    private static void stress() throws Exception {
        BankService b = new BankService();
        b.createAccounts(100, 1_000_000);
        SimulationController.Result r = new SimulationController().run(b, 20_000, 8, false, false);
        check("stress: all transactions processed", r.success + r.failed == 20_000);
        check("stress: total before = total after (adjusted)", r.invariantOk());
    }

    private static void deadlock() throws Exception {
        int hangs = 0;
        AtomicInteger timeouts = new AtomicInteger();
        for (int run = 0; run < 50; run++) {
            BankService b = new BankService();
            b.createAccounts(2, 100_000_000);
            Thread t1 = new Thread(() -> loop(b, 1, 2, timeouts));
            Thread t2 = new Thread(() -> loop(b, 2, 1, timeouts));
            t1.start();
            t2.start();
            t1.join(15_000);
            t2.join(15_000);
            if (t1.isAlive() || t2.isAlive()) hangs++;
        }
        check("deadlock test: 50 runs, zero hangs", hangs == 0);
        check("deadlock test: zero lock timeouts", timeouts.get() == 0);
    }

    private static void loop(BankService b, int from, int to, AtomicInteger timeouts) {
        for (int i = 0; i < 1000; i++) {
            try {
                b.transfer(from, to, 100);
            } catch (BankException e) {
                if (e.getMessage().contains("timeout")) timeouts.incrementAndGet();
            }
        }
    }
}
