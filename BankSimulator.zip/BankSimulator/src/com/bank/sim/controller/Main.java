package com.bank.sim.controller;

import com.bank.sim.dao.AccountRepository;
import com.bank.sim.dao.JdbcAccountRepository;
import com.bank.sim.exception.BankException;
import com.bank.sim.model.Account;
import com.bank.sim.model.TxnType;
import com.bank.sim.service.BankService;
import com.bank.sim.util.ConfigReader;
import com.bank.sim.util.LoggerSetup;
import com.bank.sim.util.Money;
import com.bank.sim.util.Pair;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/** Console menu: program entry point. */
public class Main {

    private static final Scanner IN = new Scanner(System.in);
    private static final SimulationController SIM = new SimulationController();

    private static ConfigReader cfg;
    private static BankService bank = new BankService();
    private static AccountRepository repo;
    private static SimulationController.Result lastResult;

    public static void main(String[] args) {
        LoggerSetup.init();
        cfg = new ConfigReader("config.properties");
        openDatabase();
        System.out.println("Default transaction type (config): "
                + cfg.getTxnType("default.txn.type", TxnType.TRANSFER));

        boolean running = true;
        while (running) {
            printMenu();
            String line = IN.hasNextLine() ? IN.nextLine().trim() : null;
            if (line == null) break; // end of input
            int choice;
            try {
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number from the menu.");
                continue;
            }
            try {
                switch (choice) {
                    case 1 -> createAccounts();
                    case 2 -> deposit();
                    case 3 -> withdraw();
                    case 4 -> transfer();
                    case 5 -> runSimulation(false);
                    case 6 -> runSimulation(true);
                    case 7 -> runDemo();
                    case 8 -> runPerformanceTest();
                    case 9 -> showReport();
                    case 0 -> running = false;
                    default -> System.out.println("Invalid choice. Please select 0-9.");
                }
            } catch (BankException e) {
                System.out.println("FAILED: " + e.getMessage()
                        + (e.getCause() != null ? " (cause: " + e.getCause().getMessage() + ")" : ""));
            } catch (NumberFormatException | ArithmeticException e) {
                System.out.println("Invalid number entered. Operation cancelled.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                running = false;
            }
        }
        if (repo != null) repo.close();
        System.out.println("Goodbye.");
    }

    // ------------------------------------------------------------------ menu

    private static void printMenu() {
        System.out.println();
        System.out.println("========== BANK TRANSACTION SIMULATOR ==========");
        System.out.println("1. Create accounts");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Transfer");
        System.out.println("5. Run single-threaded simulation");
        System.out.println("6. Run multi-threaded simulation");
        System.out.println("7. Demo: without locks vs with locks");
        System.out.println("8. Performance test (1, 2, 4, 8, 16 threads)");
        System.out.println("9. Show report");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }

    private static void openDatabase() {
        String url = cfg.get("db.url", "jdbc:sqlite:bank.db");
        try {
            repo = new JdbcAccountRepository(url);
            bank.setRepository(repo);
            bank.setPersist(true);
            System.out.println("Database connected: " + url);
        } catch (BankException e) {
            repo = null;
            System.out.println("Database not available (" + e.getMessage()
                    + "). Running with in-memory data and bank.log only.");
        }
    }

    // ------------------------------------------------------------- input help

    private static String ask(String prompt) {
        System.out.print(prompt);
        return IN.hasNextLine() ? IN.nextLine().trim() : "";
    }

    private static int askInt(String prompt, int def) {
        String s = ask(prompt + " [" + def + "]: ");
        return s.isEmpty() ? def : Integer.parseInt(s);
    }

    private static long askMoney(String prompt) {
        return Money.parse(ask(prompt));
    }

    // -------------------------------------------------------------- actions

    private static void createAccounts() throws BankException {
        int n = askInt("Number of accounts", cfg.getInt("default.accounts", 100));
        String s = ask("Starting balance in Rs [" + cfg.get("default.balance", "10000") + "]: ");
        long start = Money.parse(s.isEmpty() ? cfg.get("default.balance", "10000") : s);
        if (n < 2 || n > 100_000 || start < 0) {
            System.out.println("Need 2 to 100000 accounts and a non-negative balance.");
            return;
        }
        bank.createAccounts(n, start);
        bank.saveAllAccounts();
        System.out.println("Created " + n + " accounts. Total: " + Money.format(bank.totalBalance()));
    }

    private static void deposit() throws BankException {
        int id = Integer.parseInt(ask("Account ID: "));
        long amt = askMoney("Amount (Rs): ");
        bank.deposit(id, amt);
        System.out.println("Deposit done. New balance: "
                + Money.format(bank.getAccount(id).getBalance()));
    }

    private static void withdraw() throws BankException {
        int id = Integer.parseInt(ask("Account ID: "));
        long amt = askMoney("Amount (Rs): ");
        bank.withdraw(id, amt);
        System.out.println("Withdrawal done. New balance: "
                + Money.format(bank.getAccount(id).getBalance()));
    }

    private static void transfer() throws BankException {
        int from = Integer.parseInt(ask("From account ID: "));
        int to = Integer.parseInt(ask("To account ID: "));
        long amt = askMoney("Amount (Rs): ");
        bank.transfer(from, to, amt); // default method of the interface
        System.out.println("Transfer done. From balance: "
                + Money.format(bank.getAccount(from).getBalance())
                + ", To balance: " + Money.format(bank.getAccount(to).getBalance()));
    }

    private static boolean haveAccounts() {
        if (bank.getAccounts().size() < 2) {
            System.out.println("Create accounts first (menu option 1).");
            return false;
        }
        return true;
    }

    private static void runSimulation(boolean multi) throws InterruptedException, BankException {
        if (!haveAccounts()) return;
        int total = askInt("Number of transactions", cfg.getInt("default.txns", 1000));
        int threads = 1;
        if (multi) {
            threads = askInt("Number of threads (1-" + Account.MAX_THREADS + ")",
                    cfg.getInt("default.threads", 8));
        }
        if (total < 1 || threads < 1 || threads > Account.MAX_THREADS) {
            System.out.println("Invalid values. Transactions >= 1 and threads 1-" + Account.MAX_THREADS + ".");
            return;
        }
        bank.setPersist(false);      // per-transaction DB writes would dominate the timing
        bank.setAuditEnabled(true);  // one audit line per request goes to bank.log
        lastResult = SIM.run(bank, total, threads, false, true);
        bank.setAuditEnabled(false);
        bank.setPersist(repo != null);
        bank.saveAllAccounts();
        printResult(lastResult);
    }

    private static void printResult(SimulationController.Result r) {
        System.out.println("Accounts: " + bank.getAccounts().size()
                + "   Total before: " + Money.format(r.before));
        System.out.println("Threads: " + r.workers + "   Transactions: " + r.total);
        System.out.println("----------- FINAL REPORT -----------");
        System.out.println("Success    : " + r.success);
        System.out.println("Failed     : " + r.failed);
        System.out.printf("Time taken : %.3f s%n", r.seconds);
        System.out.printf("Throughput : %.0f txn/s%n", r.throughput);
        System.out.println("Total after: " + Money.format(r.after));
        System.out.println("Invariant  : " + (r.invariantOk() ? "PASSED" : "FAILED")
                + " (before = after, adjusted by deposits and withdrawals)");
    }

    /** FR10: same workload without locks and with locks, on fresh accounts. */
    private static void runDemo() throws InterruptedException {
        int accounts = 10, workers = 8, txns = 200_000;
        long start = 1_000_000; // Rs 10,000 each
        System.out.println("Demo: " + txns + " transfers, " + workers + " threads, "
                + accounts + " accounts (transfers only, so the total must not change).");
        for (boolean locks : new boolean[]{false, true}) {
            BankService b = new BankService(); // fresh bank, no database
            b.createAccounts(accounts, start);
            b.setUseLocks(locks);
            SimulationController.Result r = SIM.run(b, txns, workers, true, false);
            System.out.println();
            System.out.println(locks ? "WITH locks:" : "WITHOUT locks:");
            System.out.println("  Expected total: " + Money.format(r.expectedAfter));
            System.out.println("  Final total   : " + Money.format(r.after));
            if (r.invariantOk()) {
                System.out.println("  Result        : totals MATCH");
            } else {
                System.out.println("  Result        : MISMATCH, off by "
                        + Money.format(Math.abs(r.after - r.expectedAfter))
                        + " (lost updates from the race condition)");
            }
            System.out.printf("  Time          : %.3f s%n", r.seconds);
        }
    }

    private static void runPerformanceTest() throws InterruptedException {
        int total = askInt("Transactions per run", 50_000);
        int[] threadCounts = {1, 2, 4, 8, 16};
        System.out.println();
        System.out.printf("%-8s %-12s %-14s %-10s%n", "Threads", "Time (s)", "Throughput", "Invariant");
        for (int threads : threadCounts) {
            BankService b = new BankService();
            b.createAccounts(100, 1_000_000);
            SimulationController.Result r = SIM.run(b, total, threads, false, false);
            System.out.printf("%-8d %-12.3f %-14.0f %-10s%n", threads, r.seconds, r.throughput,
                    r.invariantOk() ? "PASSED" : "FAILED");
        }
    }

    private static void showReport() {
        System.out.println("============== REPORT ==============");
        if (bank.getAccounts().isEmpty()) {
            System.out.println("No accounts yet. Use option 1.");
            return;
        }
        System.out.println("Success so far : " + bank.getStats().getSuccess());
        System.out.println("Failed so far  : " + bank.getStats().getFailed());
        if (lastResult != null) {
            System.out.println("Last simulation:");
            printResult(lastResult);
        }
        List<Pair<Integer, Long>> rows = new ArrayList<>();
        for (Account a : bank.getAccounts()) {
            rows.add(new Pair<>(a.getId(), a.getBalance())); // autoboxing
        }
        rows.sort(Comparator.comparing(Pair::getKey));
        System.out.println("Balances (first 10 accounts):");
        for (int i = 0; i < Math.min(10, rows.size()); i++) {
            Pair<Integer, Long> p = rows.get(i);
            System.out.println("  Account " + p.getKey() + " : " + Money.format(p.getValue()));
        }
        if (rows.size() > 10) {
            System.out.println("  ... and " + (rows.size() - 10) + " more");
        }
        System.out.println("Total in bank: " + Money.format(bank.totalBalance()));
        Account first = rows.isEmpty() ? null : bank.getAccounts().iterator().next();
        if (first != null) {
            Account.Snapshot snap = first.new Snapshot(); // inner class needs an outer object
            System.out.println("Snapshot demo: " + snap);
        }
    }
}
