package com.bank.sim.model;

import java.util.concurrent.atomic.AtomicLong;

/** One banking request. Also used as the unit of work in the shared queue. */
public class Transaction {

    private static final AtomicLong COUNTER = new AtomicLong();

    /** Special marker placed in the queue to tell a worker thread to stop. */
    public static final Transaction POISON = new Transaction(TxnType.DEPOSIT, 0, 0, 0);

    private final long id;
    private final TxnType type;
    private final int from;
    private final int to;
    private final long amount;
    private volatile Status status = Status.PENDING;
    private volatile String message = "";

    public Transaction(TxnType type, int from, int to, long amount) {
        this.id = COUNTER.incrementAndGet();
        this.type = type;
        this.from = from;
        this.to = to;
        this.amount = amount;
    }

    public long getId() { return id; }
    public TxnType getType() { return type; }
    public int getFrom() { return from; }
    public int getTo() { return to; }
    public long getAmount() { return amount; }
    public Status getStatus() { return status; }
    public String getMessage() { return message; }

    public void setStatus(Status status) { this.status = status; }
    public void setMessage(String message) { this.message = message; }

    @Override
    public String toString() {
        return "Txn#" + id + " " + type + " from=" + from + " to=" + to
                + " amount=" + amount + " status=" + status;
    }
}
