package com.bank.sim.model;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Abstract bank account. Amounts are stored as long paise (Rs 1 = 100 paise).
 */
public abstract class Account {

    public static final int MAX_THREADS = 20; // static final constant

    private final int id;
    private final String holder;
    private long balance; // paise (deliberately NOT volatile/atomic: protected by lock)
    private final ReentrantLock lock = new ReentrantLock();

    public Account(int id, String holder, long balance) {
        this.id = id;
        this.holder = holder;
        this.balance = balance;
    }

    public abstract String getType();

    public abstract long minimumBalance();

    // Method overloading
    public void deposit(long amount) {
        balance += amount;
    }

    public void deposit(long amount, String note) {
        deposit(amount);
        System.out.println("Deposit note: " + note);
    }

    public void withdraw(long amount) {
        balance -= amount;
    }

    /** True if the account would stay at or above its minimum balance. */
    public boolean canDebit(long amount) {
        return balance - amount >= minimumBalance();
    }

    public int getId() { return id; }

    public String getHolder() { return holder; }

    public long getBalance() { return balance; }

    public ReentrantLock getLock() { return lock; }

    // Inner class (needs an Account object to be created): acc.new Snapshot()
    public class Snapshot {
        private final long takenBalance = balance;

        @Override
        public String toString() {
            return "Account " + id + " balance=" + takenBalance;
        }
    }
}
