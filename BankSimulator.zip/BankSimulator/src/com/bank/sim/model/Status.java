package com.bank.sim.model;

public enum Status { PENDING, SUCCESS, FAILED }
