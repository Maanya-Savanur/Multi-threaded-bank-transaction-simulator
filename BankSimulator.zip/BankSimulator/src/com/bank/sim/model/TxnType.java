package com.bank.sim.model;

public enum TxnType { DEPOSIT, WITHDRAW, TRANSFER }
