package com.bank.sim.model;

public class CurrentAccount extends Account {

    public CurrentAccount(int id, String holder, long balance) {
        super(id, holder, balance);
    }

    @Override public String getType() { return "CURRENT"; }

    @Override public long minimumBalance() { return 0; }
}
