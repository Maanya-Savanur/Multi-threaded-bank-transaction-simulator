package com.bank.sim.model;

public class SavingsAccount extends Account {

    public SavingsAccount(int id, String holder, long balance) {
        super(id, holder, balance); // calls the Account constructor
    }

    @Override public String getType() { return "SAVINGS"; }

    @Override public long minimumBalance() { return 100_000; } // Rs 1,000
}
