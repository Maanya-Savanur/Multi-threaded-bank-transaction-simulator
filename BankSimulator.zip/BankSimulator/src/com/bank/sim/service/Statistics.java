package com.bank.sim.service;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Thread-safe counters (wrapper classes AtomicInteger / AtomicLong). */
public class Statistics {

    private final AtomicInteger success = new AtomicInteger();
    private final AtomicInteger failed = new AtomicInteger();
    private final AtomicLong txnCounter = new AtomicLong();

    public void recordSuccess() {
        success.incrementAndGet();
        txnCounter.incrementAndGet();
    }

    public void recordFailure() {
        failed.incrementAndGet();
        txnCounter.incrementAndGet();
    }

    public int getSuccess() { return success.get(); }

    public int getFailed() { return failed.get(); }

    public long getProcessed() { return txnCounter.get(); }

    public void reset() {
        success.set(0);
        failed.set(0);
        txnCounter.set(0);
    }
}
