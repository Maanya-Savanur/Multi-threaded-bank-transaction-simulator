package com.bank.sim.service;

import com.bank.sim.dao.AccountRepository;
import com.bank.sim.exception.AccountNotFoundException;
import com.bank.sim.exception.BankException;
import com.bank.sim.exception.InsufficientFundsException;
import com.bank.sim.exception.InvalidAmountException;
import com.bank.sim.model.Account;
import com.bank.sim.model.CurrentAccount;
import com.bank.sim.model.SavingsAccount;
import com.bank.sim.model.Status;
import com.bank.sim.model.Transaction;
import com.bank.sim.model.TxnType;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

public class BankService implements BankOperations {

    private static final Logger LOG = Logger.getLogger("com.bank.sim");

    private final Map<Integer, Account> accounts = new ConcurrentHashMap<>();
    private final LockManager lockManager = new LockManager();
    private final Statistics stats = new Statistics();
    private final Object auditLock = new Object();

    /** Net money that entered (deposits) minus left (withdrawals) the bank. */
    private final AtomicLong netExternal = new AtomicLong();

    private volatile boolean useLocks = true;       // false only for the "without locks" demo
    private volatile boolean auditEnabled = false;  // writes one audit line per request to bank.log
    private volatile boolean persist = false;       // writes balances / txn log to the database
    private volatile AccountRepository repository;

    // ---------------------------------------------------------------- setup

    public void setUseLocks(boolean useLocks) { this.useLocks = useLocks; }

    public void setAuditEnabled(boolean auditEnabled) { this.auditEnabled = auditEnabled; }

    public void setPersist(boolean persist) { this.persist = persist; }

    public void setRepository(AccountRepository repository) { this.repository = repository; }

    public void addAccount(Account a) { accounts.put(a.getId(), a); }

    /** Replaces all accounts with 1..count (odd = Savings, even = Current). */
    public void createAccounts(int count, long startBalance) {
        accounts.clear();
        netExternal.set(0);
        stats.reset();
        for (int i = 1; i <= count; i++) {
            Account a = (i % 2 == 1)
                    ? new SavingsAccount(i, "Holder" + i, startBalance)
                    : new CurrentAccount(i, "Holder" + i, startBalance);
            accounts.put(i, a);
        }
    }

    public Collection<Account> getAccounts() { return accounts.values(); }

    public Account getAccount(int id) throws AccountNotFoundException {
        Account a = accounts.get(id);
        if (a == null) {
            throw new AccountNotFoundException("Unknown account " + id);
        }
        return a;
    }

    public Statistics getStats() { return stats; }

    public long getNetExternal() { return netExternal.get(); }

    public long totalBalance() {
        long sum = 0;
        for (Account a : accounts.values()) {
            sum += a.getBalance();
        }
        return sum;
    }

    // ----------------------------------------------------------- operations

    public void deposit(int id, long amount) throws BankException {
        if (!BankOperations.isValidAmount(amount)) {
            throw new InvalidAmountException("Amount must be greater than zero");
        }
        Account a = getAccount(id);
        boolean locked = false;
        try {
            if (useLocks) {
                a.getLock().lock();
                locked = true;
            }
            a.deposit(amount);
            netExternal.addAndGet(amount);
        } finally {
            if (locked) a.getLock().unlock();
            if (auditEnabled) {
                synchronized (auditLock) {
                    audit(Thread.currentThread().getName(), id, 0, amount);
                }
            }
        }
        recordSuccess(new Transaction(TxnType.DEPOSIT, id, 0, amount));
    }

    public void withdraw(int id, long amount) throws BankException {
        if (!BankOperations.isValidAmount(amount)) {
            throw new InvalidAmountException("Amount must be greater than zero");
        }
        Account a = getAccount(id);
        boolean locked = false;
        try {
            if (useLocks) {
                a.getLock().lock();
                locked = true;
            }
            if (!a.canDebit(amount)) {
                throw new InsufficientFundsException("Insufficient funds in " + id);
            }
            a.withdraw(amount);
            netExternal.addAndGet(-amount);
        } finally {
            if (locked) a.getLock().unlock();
            if (auditEnabled) {
                synchronized (auditLock) {
                    audit(Thread.currentThread().getName(), id, 0, amount);
                }
            }
        }
        recordSuccess(new Transaction(TxnType.WITHDRAW, id, 0, amount));
    }

    @Override
    public void transfer(int fromId, int toId, long amount, String note) throws BankException {
        if (!BankOperations.isValidAmount(amount) || fromId == toId) {
            throw new InvalidAmountException("Invalid transfer request");
        }
        Account from = accounts.get(fromId);
        Account to = accounts.get(toId);
        if (from == null || to == null) {
            throw new AccountNotFoundException("Unknown account");
        }

        Account[] pair = lockManager.inOrder(from, to); // lower ID first
        Account first = pair[0], second = pair[1];
        boolean firstLocked = false, secondLocked = false;
        boolean locking = useLocks;
        try {
            if (locking) {
                firstLocked = first.getLock().tryLock(2, TimeUnit.SECONDS);
                secondLocked = firstLocked && second.getLock().tryLock(2, TimeUnit.SECONDS);
                if (!secondLocked) {
                    throw new BankException("Lock timeout, transfer aborted");
                }
            }
            // check and update inside ONE locked section
            if (!from.canDebit(amount)) {
                throw new InsufficientFundsException("Insufficient funds in " + fromId);
            }
            from.withdraw(amount);
            to.deposit(amount);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new BankException("Transfer interrupted", e);
        } finally {
            if (secondLocked) second.getLock().unlock(); // always released
            if (firstLocked) first.getLock().unlock();
            if (auditEnabled) {
                synchronized (auditLock) { // one audit line at a time
                    audit(Thread.currentThread().getName(), fromId, toId, amount);
                }
            }
        }
        recordSuccess(new Transaction(TxnType.TRANSFER, fromId, toId, amount));
    }

    // -------------------------------------------------------- bookkeeping

    public void recordFailure(Transaction t, String reason) {
        t.setStatus(Status.FAILED);
        t.setMessage(reason);
        stats.recordFailure();
        if (auditEnabled) {
            LOG.warning(t + " reason=" + reason);
        }
        if (persist && repository != null) {
            try {
                repository.logTxn(t);
            } catch (BankException e) {
                LOG.warning("DB log failed: " + e.getMessage());
            }
        }
    }

    private void recordSuccess(Transaction t) {
        t.setStatus(Status.SUCCESS);
        stats.recordSuccess();
        if (persist && repository != null) {
            try {
                repository.logTxn(t);
                saveBalance(t.getFrom());
                if (t.getTo() > 0 && t.getTo() != t.getFrom()) {
                    saveBalance(t.getTo());
                }
            } catch (BankException e) {
                LOG.warning("DB write failed: " + e.getMessage() + " cause=" + e.getCause());
            }
        }
    }

    private void saveBalance(int id) throws BankException {
        Account a = accounts.get(id);
        if (a != null) {
            repository.save(a);
        }
    }

    /** Writes every account balance to the database (used after simulations). */
    public void saveAllAccounts() throws BankException {
        if (repository == null) return;
        for (Account a : accounts.values()) {
            repository.save(a);
        }
    }

    private void audit(String thread, int fromId, int toId, long amount) {
        LOG.info("AUDIT thread=" + thread + " from=" + fromId + " to=" + toId + " amount=" + amount);
    }
}
