package com.bank.sim.service;

import com.bank.sim.model.Account;

public class LockManager {

    /** Always returns the account with the lower ID first (breaks circular wait). */
    public Account[] inOrder(Account a, Account b) {
        return a.getId() < b.getId() ? new Account[]{a, b} : new Account[]{b, a};
    }
}
