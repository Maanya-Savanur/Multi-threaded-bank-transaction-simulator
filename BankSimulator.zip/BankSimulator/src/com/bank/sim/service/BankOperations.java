package com.bank.sim.service;

import com.bank.sim.exception.BankException;

public interface BankOperations {

    // abstract method
    void transfer(int fromId, int toId, long amount, String note) throws BankException;

    // default method: 3-argument version calls the 4-argument one (overloading)
    default void transfer(int fromId, int toId, long amount) throws BankException {
        log("Default transfer used");
        transfer(fromId, toId, amount, "Transfer");
    }

    // static method: no object needed
    static boolean isValidAmount(long amount) {
        return amount > 0;
    }

    // private method: helper hidden from implementing classes
    private void log(String message) {
        // kept silent on the console during simulations; uncomment to see it:
        // System.out.println("[BankOperations] " + message);
    }
}
