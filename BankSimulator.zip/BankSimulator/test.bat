@echo off
rem Run the self-test (unit checks, stress test, deadlock test)
cd /d "%~dp0"
java -cp "out;lib\*" com.bank.sim.controller.SelfTest
