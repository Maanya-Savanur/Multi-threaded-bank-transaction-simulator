# Multi-threaded Bank Transaction Simulator

Java project for 1BCS302 Object Oriented Programming with Java.
Needs **JDK 17 or newer** (uses switch expressions and pattern matching for instanceof).

## Folder layout

```
BankSimulator/
├── src/com/bank/sim/{model,service,worker,dao,exception,util,controller}
├── lib/            <- put sqlite-jdbc.jar here (optional)
├── out/            <- compiled classes (created by the build script)
├── config.properties
├── build.sh / run.sh / test.sh      (Linux, macOS)
└── build.bat / run.bat / test.bat   (Windows)
```

## Build and run

Linux / macOS:

    chmod +x *.sh
    ./build.sh
    ./run.sh

Windows (Command Prompt):

    build.bat
    run.bat

Or by hand:

    javac -d out -cp "lib/*" $(find src -name "*.java")
    java -cp "out:lib/*" com.bank.sim.controller.Main          (Windows: use ; instead of :)

## Database (SQLite) is optional

The program compiles and runs without the JDBC driver. If the driver jar is missing it prints
"Database not available" and works in memory, writing the audit trail to `bank.log`.

To enable the database, download a `sqlite-jdbc` jar from Maven Central
(https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/), put it in `lib/`, and run again.
`bank.db` is created automatically. If a newer jar complains about a missing slf4j class,
also add the `slf4j-api` jar to `lib/`, or use an older sqlite-jdbc such as 3.41.2.2.

## Self-test (no JUnit needed)

    ./test.sh        (Windows: test.bat)

Covers deposit/withdraw/transfer, every exception type, a 20,000-transaction concurrency
stress test (invariant check) and 50 runs of opposing transfers A->B / B->A (zero hangs).

## Menu quick start

1. Option 1: create accounts (press Enter to accept 100 accounts, Rs 10,000 each).
2. Option 6: multi-threaded simulation (Enter for 1000 transactions, 8 threads).
3. Option 7: demo showing lost updates without locks vs correct totals with locks.
4. Option 8: performance test with 1, 2, 4, 8, 16 threads.
5. Option 9: report.

Amounts are typed in rupees (e.g. `250.50`) and stored internally as long paise.
Settings live in `config.properties`.
