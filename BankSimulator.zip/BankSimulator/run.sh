#!/bin/sh
# Run the console application (run ./build.sh first)
cd "$(dirname "$0")" || exit 1
java -cp "out:lib/*" com.bank.sim.controller.Main
