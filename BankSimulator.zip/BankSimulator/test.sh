#!/bin/sh
# Run the self-test (unit checks, stress test, deadlock test)
cd "$(dirname "$0")" || exit 1
java -cp "out:lib/*" com.bank.sim.controller.SelfTest
