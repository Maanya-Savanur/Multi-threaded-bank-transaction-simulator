#!/bin/sh
# Compile everything into ./out  (the JDBC jar is only needed at run time)
cd "$(dirname "$0")" || exit 1
mkdir -p out lib
javac -d out -cp "lib/*" $(find src -name "*.java") && echo "Build OK"
