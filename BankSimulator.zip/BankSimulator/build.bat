@echo off
rem Compile everything into out\  (the JDBC jar is only needed at run time)
cd /d "%~dp0"
if not exist out mkdir out
if not exist lib mkdir lib
dir /s /b src\*.java > sources.txt
javac -d out -cp "lib\*" @sources.txt
if %errorlevel%==0 echo Build OK
